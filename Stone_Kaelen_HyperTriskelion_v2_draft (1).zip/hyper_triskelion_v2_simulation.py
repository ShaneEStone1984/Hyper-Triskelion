
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa

def delta_t_base(t, t_future=2.0):
    return t_future - t

def t_future_osc(t):
    return 2.0 + 0.5 * np.sin(2*np.pi*t)

def epsilon(theta, t):
    return 0.1 * np.sin(3*theta + 2*np.pi*t)

def radius_base(theta, t):
    return 1.0

def radius_coupled(theta, t):
    r0 = 1.0 + 0.3 * np.sin(2*np.pi*t)
    eps = epsilon(theta, t)
    return r0 * np.exp(eps * np.sin(theta))

def mu_gain(r, t):
    return 0.2 + 0.1 * np.sin(r + np.pi*t)

def lambda_gain(theta, t):
    return 0.1 + 0.2 * np.sin(4*theta + np.pi*t)

def nu_gain(eps):
    return 0.15 + 0.1 * eps

def delta_t_coupled(theta, phi, t):
    tf = t_future_osc(t)
    base = tf - t
    r = radius_coupled(theta, t)
    eps = epsilon(theta, t)
    mu = mu_gain(r, t)
    lam = lambda_gain(theta, t)
    nu = nu_gain(eps)
    arm_term   = 1.0 + 0.2 * np.sin(phi + np.pi*t)
    theta_term = 1.0 + mu * np.sin(2*theta + np.pi*t)
    radial_gain = 1.0 + lam * np.sin(r)
    noise = nu * eps * 0.1
    return base * arm_term * theta_term * radial_gain + noise

def point(theta, phi, t, mode="base"):
    if mode == "base":
        dt = delta_t_base(t)
        r = radius_base(theta, t)
        k_vert = 1.0
    else:
        dt = delta_t_coupled(theta, phi, t)
        r = radius_coupled(theta, t)
        k_vert = 3.0
    x = (r + dt*np.cos(theta)) * np.cos(theta + phi + np.sin(dt))
    y = (r + dt*np.cos(theta)) * np.sin(theta + phi + np.sin(dt))
    z = dt*np.sin(theta) + np.cos(k_vert*theta/2.0)
    w = dt*np.sin(k_vert*theta/2.0)
    return x,y,z,w

def plot_mode(mode, tag):
    phis = [0.0, 2*np.pi/3, 4*np.pi/3]
    theta_vals = np.linspace(0, 2*np.pi, 1500)
    t_samples = [0.0, 0.25, 0.5, 0.75, 1.0]

    fig = plt.figure(figsize=(7,6))
    ax = fig.add_subplot(111, projection='3d')
    for t in t_samples:
        for phi in phis:
            xs,ys,zs = [],[],[]
            for th in theta_vals:
                x,y,z,w = point(th, phi, t, mode=mode)
                xs.append(x); ys.append(y); zs.append(z)
            ax.plot(xs, ys, zs)
    ax.set_xlabel("x"); ax.set_ylabel("y"); ax.set_zlabel("z")
    ax.set_title(f"Hyper-Triskelion ({tag}) — 3D projection (x,y,z)")
    plt.tight_layout()
    plt.savefig(f"hyper_triskelion_{tag}_xyz.png", dpi=200)
    plt.close()

    plt.figure(figsize=(6,6))
    for t in t_samples:
        for phi in phis:
            xs,ys = [],[]
            for th in theta_vals:
                x,y,z,w = point(th, phi, t, mode=mode)
                xs.append(x); ys.append(y)
            plt.plot(xs, ys)
    plt.gca().set_aspect('equal', adjustable='box')
    plt.xlabel("x"); plt.ylabel("y")
    plt.title(f"Hyper-Triskelion ({tag}) — 2D projection (x,y)")
    plt.tight_layout()
    plt.savefig(f"hyper_triskelion_{tag}_xy.png", dpi=200)
    plt.close()

if __name__ == "__main__":
    plot_mode("base", "base")
    plot_mode("coupled", "coupled")
    print("Generated base and coupled Hyper-Triskelion projections.")
