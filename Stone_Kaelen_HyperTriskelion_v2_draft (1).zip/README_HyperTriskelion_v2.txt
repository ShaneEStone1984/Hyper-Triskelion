
README — Stone–Kaelen Hyper-Triskelion v2 Draft
===============================================

This package is a working bundle for future Zenodo updates.

Files:
- hyper_triskelion_v2_equations.txt
    Short description of the base system and one example fully coupled mode.

- hyper_triskelion_base_xyz.png
- hyper_triskelion_base_xy.png
    3D and 2D projections of the original system.

- hyper_triskelion_coupled_xyz.png
- hyper_triskelion_coupled_xy.png
    3D and 2D projections of an example fully coupled feedback system.

- hyper_triskelion_v2_simulation.py
    Python script to regenerate and experiment with the system.

Author: Shane Edward Stone
